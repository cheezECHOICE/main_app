import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:food/data/repositories/authentication_repo.dart';
import 'package:food/features/shop/models/order_model.dart';
import 'package:food/utils/constants/api_constants.dart';
import 'package:get/get.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class OrderRepository extends GetxController {
  static OrderRepository get instance => Get.find();
  final _db = FirebaseFirestore.instance;
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  final orderEndpoint = '$dbLink/orders';
  final userOrderEndpoint = '$dbLink/orders?userId=';

  /// Get the FCM Token
  Future<String?> getFcmToken() async {
    try {
      String? fcmToken = await _firebaseMessaging.getToken();
      if (fcmToken == null) {
        throw 'Unable to get FCM token';
      }
      return fcmToken;
    } catch (e) {
      print('Error fetching FCM token: $e');
      rethrow;
    }
  }

  /// Store FCM Token in Prisma
  Future<void> saveFcmTokenInPrisma(String userId, String? fcmToken) async {
    try {
      if (fcmToken != null) {
        await Dio().post('$dbLink/user', data: {
          'id': userId,
          'fcm Token': fcmToken,
        });
      }
    } catch (e) {
      print('Error updating FCM token: $e');
      throw 'Something went wrong while updating FCM Token.';
    }
  }

  /// Store new user order
  Future<void> saveOrder(OrderModel order, String userId) async {
    try {
      await _db
          .collection('Users')
          .doc(userId)
          .collection('Orders')
          .add(order.toJson());
      
    } catch (e) {
      throw 'Something went wrong while saving Order Information. Try again later';
    }
  }

  // Prisma order
  Future<void> pushOrder(int brandId, String address, double totalAmount,
      String userId, List<Map<String, dynamic>> products) async {
    try {
      await Dio().post(orderEndpoint, data: {
        'brandId': brandId,
        'address': address,
        'totalamount': totalAmount,
        'userId': userId,
        'products': products
      });
      
      // Update FCM token when placing an order
      String? fcmToken = await getFcmToken();
      await saveFcmTokenInPrisma(userId, fcmToken);
      
    } catch (e) {
      throw 'Something went wrong while saving Order Information. Try again later';
    }
  }
  
  // Fetch user orders
  Future<List<OrderModel>> fetchUserOrdersPrisma() async {
    List<OrderModel> orders = [];
    try {
      var data = await Dio().get(
          '${userOrderEndpoint}${AuthenticationRepository.instance.authUser?.uid}');
      
      for (var item in data.data['data']) {
        orders.add(OrderModel.fromJson(item));
      }
      
    } catch (e) {
      print(e);
      throw 'Something went wrong while fetching Order Information. Try again later';
    }
    return orders;
  }
}

