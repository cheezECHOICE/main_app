import 'package:easy_refresh/easy_refresh.dart';
import 'package:flutter/material.dart';
import 'package:food/features/shop/controllers/brand_controller.dart';
import 'package:food/features/shop/screens/store/widgets/search_bar.dart';
import 'package:food/features/shop/screens/store/widgets/store_card.dart';
import 'package:food/utils/constants/sizes.dart';
import 'package:food/utils/shimmers/store_shimmer.dart';
import 'package:get/get.dart';

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final brandController = Get.put(BrandController());
    final TextEditingController searchController = TextEditingController();

    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8.0),
          child: Column(
            children: [
              MySearchBar(
                searchController: searchController,
                searchHint: 'Search for your favourite store',
                filterFunction: brandController.filterBrands,
              ),
              const SizedBox(height: 1.5 * TSizes.spaceBtwItems),
              Expanded(
                child: EasyRefresh(
                  onRefresh: brandController.getAllBrands,
                  child: Obx(() {
                    if (brandController.isLoading.value) {
                      return SingleChildScrollView(
                        child: const TStoreShimmer(),
                      );
                    }

                    if (brandController.brandsToShow.isEmpty) {
                      brandController.getAllBrands();
                      return const Center(
                        child: Text('No stores found.'),
                      );
                    }

                    return ListView.builder(
                      itemCount: brandController.brandsToShow.length,
                      itemBuilder: (context, index) {
                        final store = brandController.brandsToShow[index];
                        return Column(
                          children: [
                            StoreCard(store: store),
                            const SizedBox(height: 1.25 * TSizes.spaceBtwItems),
                          ],
                        );
                      },
                    );
                  }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
