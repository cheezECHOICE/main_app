import 'package:flutter/material.dart';
import 'package:food/common/widgets/custom_shapes/container/primary_header_container.dart';
import 'package:food/features/personalisation/screens/address/widgets/add_new_address_screen.dart';
import 'package:food/features/personalisation/screens/profile/widgets/profile.dart';
import 'package:food/features/shop/screens/home/widgets/home_appbar.dart';
import 'package:food/features/shop/screens/home/widgets/home_categories.dart';
import 'package:food/features/shop/screens/home/widgets/popular_products.dart';
import 'package:food/features/shop/screens/home/widgets/promo_slider.dart';
import 'package:food/features/shop/screens/home/widgets/search_container.dart';
import 'package:food/features/shop/screens/home/widgets/title_divider.dart';
import 'package:food/features/shop/screens/orders/order.dart';
import 'package:food/utils/constants/colors.dart';
import 'package:food/utils/constants/sizes.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  bool _isOpen = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 300),
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleMenu() {
    setState(() {
      _isOpen = !_isOpen;
      if (_isOpen) {
        _controller.forward();
      } else {
        _controller.reverse();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            TPrimaryHeaderContainer(
              child: Column(
                children: [
                  // Appbar
                  THomeAppBar(),

                  // SearchBar
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.0),
                    child: SearchContainer(),
                  ),
                  SizedBox(height: 0.5 * TSizes.spaceBtwSections),

                  PromoSlider(),
                  SizedBox(height: TSizes.spaceBtwSections),
                ],
              ),
            ),

            // Categories
            SizedBox(height: TSizes.spaceBtwInputFields),
            Padding(
              padding:
                  EdgeInsets.symmetric(horizontal: TSizes.defaultSpace / 2),
              child: Column(
                children: [
                  TitleDivider(
                    title: 'Categories',
                  ),
                  SizedBox(height: TSizes.spaceBtwItems - 2),

                  // Categories
                  THomeCategories(),
                ],
              ),
            ),
            SizedBox(height: TSizes.spaceBtwItems),

            // Popular Products
            Padding(
              padding: EdgeInsets.symmetric(horizontal: TSizes.defaultSpace),
              child: Column(
                children: [
                  TitleDivider(
                    title: 'Popular Items',
                  ),
                  SizedBox(height: TSizes.spaceBtwItems),
                  PopularProducts(),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _toggleMenu,
        child: AnimatedIcon(
          icon: AnimatedIcons.view_list,
          progress: _animation,
        ),
        backgroundColor: TColors.primary.withOpacity(0.8),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      // Menu options
      bottomNavigationBar: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        curve: Curves.linear,
        height: _isOpen ? 200.0 : 0.0,
        decoration: BoxDecoration(
          color: TColors.primary.withOpacity(0.8),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(_isOpen ? 100.0 : 0.0),
          ),
        ),
        child: _isOpen
            ? Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildMenuItem(Icons.person, 'Profile', ProfileScreen()),
                  _buildMenuItem(
                      Icons.shopping_bag, 'Orders', OrderScreen()),
                  _buildMenuItem(Icons.location_on, 'Address', AddNewAddressScreen()),
                ],
              )
            : null,
      ),
    );
  }

  Widget _buildMenuItem(IconData icon, String label, Widget page) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Icon(
            icon,
            color: Colors.white,
          ),
          SizedBox(width: 10.0),
          Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16.0,
            ),
          ),
          SizedBox(width: 20.0),
        ],
      ),
    );
  }
}
