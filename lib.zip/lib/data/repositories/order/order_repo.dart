import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:food/data/repositories/authentication_repo.dart';
import 'package:food/features/shop/models/order_model.dart';
import 'package:food/utils/constants/api_constants.dart';
import 'package:get/get.dart';

class OrderRepository extends GetxController {
  static OrderRepository get instance => Get.find();
  

  /// Variables
  final _db = FirebaseFirestore.instance;
  final orderEndpoint = '$dbLink/orders';
  final userOrderEndpoint = '$dbLink/orders?userId=';


  // Future<void> updateStoreStatus(String storeId, bool isOpen) async {
  //   try {
  //     await userOrderEndpoint.updateStoreStatus(storeId, isOpen);
  //   } catch (e) {
  //     print("Error updating store status: $e");
  //     rethrow;
  //   }
  // }
  /// Get all order related to current User
  Future<List<OrderModel>> fetchUserOrders() async {
    try {
      final userId = AuthenticationRepository.instance.authUser?.uid;
      if (userId!.isEmpty) {
        throw 'Unable to find user information. Try again in few minutes.';
      }
      final result =
          await _db.collection('Users').doc(userId).collection('Orders').get();
      return result.docs
          .map((documentSnapshot) => OrderModel.fromSnapshot(documentSnapshot))
          .toList();
    } catch (e) {
      throw 'Something went wrong while fetching Order Information. Try again later';
    }
  }

  /// Store new user order
  Future<void> saveOrder(OrderModel order, String userId) async {
    try {
      await _db
          .collection('Users')
          .doc(userId)
          .collection('Orders')
          .add(order.toJson());
    } catch (e) {
      throw 'Something went wrong while saving Order Information. Try again later';
    }
  }

  // Prisma order
  Future<void> pushOrder(int brandId, String address, double totalAmount,
      String userId, List<Map<String, dynamic>> products) async {
    try {
      await Dio().post(orderEndpoint, data: {
        'brandId': brandId,
        'address': address,
        'totalamount': totalAmount,
        'userId': userId,
        'products': products
      });
    } catch (e) {
      throw 'Something went wrong while saving Order Information. Try again later';
    }
  }

  Future<List<OrderModel>> fetchUserOrdersPrisma() async {
    List<OrderModel> orders = [];
    try {
      var data = await Dio().get(
          '${userOrderEndpoint}${AuthenticationRepository.instance.authUser?.uid}');

      for (var item in data.data['data']) {
        orders.add(OrderModel.fromJson(item));
      }
    } catch (e) {
      print(e);
      throw 'Something went wrong while fetching Order Information. Try again later';
    }
    return orders;
  }
}
